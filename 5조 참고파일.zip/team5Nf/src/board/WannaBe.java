package board;

public class WannaBe {
	private String u_id;
	private String u_pwd;
	private String u_name;
	private String u_email;
	private int u_phone;
	private int u_birth;
	private String u_sex;
	private int u_manager;
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pwd() {
		return u_pwd;
	}
	public void setU_pwd(String u_pwd) {
		this.u_pwd = u_pwd;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_email() {
		return u_email;
	}
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
	public int getU_phone() {
		return u_phone;
	}
	public void setU_phone(int u_phone) {
		this.u_phone = u_phone;
	}
	public int getU_birth() {
		return u_birth;
	}
	public void setU_birth(int u_birth) {
		this.u_birth = u_birth;
	}
	public String getU_sex() {
		return u_sex;
	}
	public void setU_sex(String u_sex) {
		this.u_sex = u_sex;
	}
	public int getU_manager() {
		return u_manager;
	}
	public void setU_manager(int u_manager) {
		this.u_manager = u_manager;
	}

}
