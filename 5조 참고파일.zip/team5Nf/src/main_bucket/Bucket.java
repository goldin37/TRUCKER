package main_bucket;

public class Bucket {
	private int bl_num;
	private String bl_title;
	private int bl_like;
	private String user_tbl_u_id;
	
	
	public int getBl_num() {
		return bl_num;
	}
	public void setBl_num(int bl_num) {
		this.bl_num = bl_num;
	}
	public String getBl_title() {
		return bl_title;
	}
	public void setBl_title(String bl_title) {
		this.bl_title = bl_title;
	}
	public int getBl_like() {
		return bl_like;
	}
	public void setBl_like(int bl_like) {
		this.bl_like = bl_like;
	}
	public String getUser_tbl_u_id() {
		return user_tbl_u_id;
	}
	public void setUser_tbl_u_id(String user_tbl_u_id) {
		this.user_tbl_u_id = user_tbl_u_id;
	}
	
	
}
