package trucker;

public class TruckerBean {
	private String driver_id;
	private String driver_password;
	private String driver_jumin; 
	private String driver_license;
	private String driver_password_check;
	private String driver_name; 
	private String driver_phone_number;
	private String driver_address; 
	private String driver_email; 
	private String driver_position; 
	private String truck_type;
	private String truck_number; 
	private String driver_picture; 
	private String driver_evaluation;
	public String getDriver_id() {
		return driver_id;
	}
	public void setDriver_id(String driver_id) {
		this.driver_id = driver_id;
	}
	public String getDriver_password() {
		return driver_password;
	}
	public void setDriver_password(String driver_password) {
		this.driver_password = driver_password;
	}
	public String getDriver_jumin() {
		return driver_jumin;
	}
	public void setDriver_jumin(String driver_jumin) {
		this.driver_jumin = driver_jumin;
	}
	public String getDriver_license() {
		return driver_license;
	}
	public void setDriver_license(String driver_license) {
		this.driver_license = driver_license;
	}
	public String getDriver_password_check() {
		return driver_password_check;
	}
	public void setDriver_password_check(String driver_password_check) {
		this.driver_password_check = driver_password_check;
	}
	public String getDriver_name() {
		return driver_name;
	}
	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}
	public String getDriver_phone_number() {
		return driver_phone_number;
	}
	public void setDriver_phone_number(String driver_phone_number) {
		this.driver_phone_number = driver_phone_number;
	}
	public String getDriver_address() {
		return driver_address;
	}
	public void setDriver_address(String driver_address) {
		this.driver_address = driver_address;
	}
	public String getDriver_email() {
		return driver_email;
	}
	public void setDriver_email(String driver_email) {
		this.driver_email = driver_email;
	}
	public String getDriver_position() {
		return driver_position;
	}
	public void setDriver_position(String driver_position) {
		this.driver_position = driver_position;
	}
	public String getTruck_type() {
		return truck_type;
	}
	public void setTruck_type(String truck_type) {
		this.truck_type = truck_type;
	}
	public String getTruck_number() {
		return truck_number;
	}
	public void setTruck_number(String truck_number) {
		this.truck_number = truck_number;
	}
	public String getDriver_picture() {
		return driver_picture;
	}
	public void setDriver_picture(String driver_picture) {
		this.driver_picture = driver_picture;
	}
	public String getDriver_evaluation() {
		return driver_evaluation;
	}
	public void setDriver_evaluation(String driver_evaluation) {
		this.driver_evaluation = driver_evaluation;
	}
	

}
