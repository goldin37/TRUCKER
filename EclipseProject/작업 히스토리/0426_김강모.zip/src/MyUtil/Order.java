package MyUtil;

import java.sql.Timestamp;

public class Order {
	private int order_id;
	private String truck_type;
	private String from;
	private String from_spec;
	private Timestamp depart_time;
	private String to;
	private String to_spec;
	private String cargo_type;
	
}
