package myUtill;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class queryDB {
	private static queryDB instance = new queryDB();

	public static queryDB getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception{
		Context ctx=new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public DeliveryOrder getOrder(int bid) {
		Connection con=null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql="";
		DeliveryOrder order = null;
		
		try {
			con = getConnection(); // 6���� �׽�Ʈ
						
			sql = "select TRUCK_TYPE \r\n" + 		 	// �������
					"        , ORDER_STATE\r\n" +    	// ��ۻ���
					"        , FROM_WHERE\r\n" +     	// ����� �ּ�
					"        , DEPART_DATE_TIME\r\n" +  // ����Ͻ�
					"        , TO_WHERE\r\n" +    	    // ������ �ּ� 
					"        , ARRIVE_DATE_TIME\r\n" +  // �����Ͻ�
					"        from DELIVERY_ORDER\r\n" +  // ���̺� ��
					"        where ORDER_ID = ?";  	    // ��� ��ȣ = ?
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bid);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				order=new DeliveryOrder();
				order.setTruck_type(rs.getString(1));
				order.setOrder_state(rs.getString(2));
				order.setFrom(rs.getString(3));
				order.setDepart_date_time(rs.getTimestamp(4));
				order.setTo(rs.getString(5));
				order.setArrive_date_time(rs.getTimestamp(6));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return order;
	}
}
